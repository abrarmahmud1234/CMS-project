<?php include "header.php";
include "config.php" ;
if($_SESSION['role']==0){
 header("Location: {$hostname}/admin/post.php");
}
if(isset($_POST['submit'])){
  $id=$_POST['user_id']  ;
 
$sql1="DELETE FROM user
WHERE user_id = '$id';";
if(mysqli_query($conn,$sql1)){
       header("Location: {$hostname}/admin/users.php");
    }

}
?>
 <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading">Delete User Details</h1>
              </div>


              <div class="col-md-offset-4 col-md-4">
                  <!-- Form Start -->

                  
                  <?php
                  $id=$_GET['id'];
                  $sql="select * from user where user_id='$id'";
                  $result=mysqli_query($conn,$sql);
                  if(mysqli_num_rows($result)>0){
                    while($row=mysqli_fetch_assoc($result)){
                  ?>
                  <form  action="<?php $_SERVER['PHP_SELF'];?>" method ="POST">
                      <div class="form-group">
                          <input type="" name="user_id"  class="form-control" value="<?php echo $row['user_id'];?>" placeholder="Enter Id" >
                      </div>
                       <input type="submit" name="submit" class="btn btn-primary" value="Delete" required />
                  </form>
                  <?php }} ?>
              </div>
          </div>
      </div>
 </div>
 <?php include "footer.php"; ?>
                   

