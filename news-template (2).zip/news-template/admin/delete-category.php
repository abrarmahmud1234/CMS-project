<?php
include "config.php";
$id=$_GET['id'];
$sql="delete from category where category_id='$id'";
if(mysqli_query($conn,$sql)){
     header("Location: {$hostname}/admin/category.php");
}
?>